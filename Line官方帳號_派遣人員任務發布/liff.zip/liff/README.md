# LIFF 調度員手機端

三個頁面，共用同一份 `tasks.js` 與同一份 localStorage 狀態（`yb_progress`）。

| 頁面 | 進入點 | 做什麼 |
|---|---|---|
| `index.html` | 一般派工卡的「開啟調度路線」 | 任務列表、路線地圖、導航、到站回報、完成整趟 |
| `urgent.html` | **緊急派送卡的「查看緊急任務」** | 這筆等了多久、為何升級、要不要接 |
| `log.html` | 任務頁右上角的日誌鈕 | 累計省下的里程與碳排 |

## 為什麼緊急派送要獨立一頁

一般任務頁的閱讀順序是「挑一筆來做」；緊急派送是「這筆沒人接，現在要不要接」。
所以 `urgent.html` 先講**已經等多久、為什麼輪到你**，確認動作只有一個，
而且**不載入地圖圖磚**——緊急情境下多一個外部相依就多一個失敗點，改用文字路線。
接單成功後才跳到 `index.html?taskId=…` 執行任務，狀態接得上，不用重接一次。

卡片按鈕走 LIFF 子路徑：`https://liff.line.me/{liffId}/urgent.html?taskId=T005&waited=23`，
所以**只需要一個 LIFF ID**，不必為這頁另開一個。

## 列表排序：依派工緊急度，不是時段先後

`index.html` 的待處理清單與**後端 `nextPendingTask`、大螢幕的下拉選單同一套排序**：
`dispatchUrgency` 由高到低（可挽回租借次數 40 ＋ 空滿程度 25 ＋ 有效失衡時間 20
＋ 處理效率 10 ＋ 轉運節點 5）。已接下／已被接走／已完成依序往下沉，
排第一且**仍待接收**的那筆標「建議先接」——正在跑的任務不該再被建議一次。

卡片上**不顯示失衡時段**。那是回放資料的時間戳，清單既然不按時間排，
把它留在卡片上只會讓人以為漏了早上的任務。時段仍保留在任務詳情頁（「HH:MM 觸發」），
在那裡它是單筆任務的背景資訊，不是排序依據。卡片左上角改放名次（#1、#2…）。

三個地方必須一致，否則調度員手機上看到的順序，會跟系統「為什麼先派這一筆」的說法對不起來。

**失衡久不等於排前面**，這是刻意的。例如同一份資料裡：

| 首要站 | 缺車時數 | 已流失 | ETA | 緊急度 |
|---|---|---|---|---|
| 板橋 四維公園地下停車場 | 7 小時 | 88 次 | 20 分 | **97（第 1）** |
| 新莊 新月橋 | 9.5 小時 | 89 次 | 40 分 | 88（第 3） |
| 林口 井泉公園 | 7.5 小時 | 30 次 | 69 分 | **69（第 8）** |

井泉公園每小時只有 4 次借還，四維公園是 12.2 次——同樣空一小時，一個少做 4 趟、
一個少做 12 趟。再加上車程差距，同一個人同一段時間去板橋能救回的次數高得多。
列表頂端有一行灰字把這個排序依據寫出來，免得看的人以為漏了早上的任務。

## 檔案

| 檔案 | 用途 |
|---|---|
| `index.html` | 任務頁（HTML/CSS/JS 全部內嵌，只外連 Leaflet 與 LIFF SDK） |
| `urgent.html` | 緊急派送頁（只外連 LIFF SDK，**不載地圖**） |
| `log.html` | 調度日誌（零外部相依） |
| `tasks.js` | `window.__TASKS__ = {...}`，**雙擊本機開啟時用這份** |
| `tasks.json` | 同樣內容的 JSON，部署到伺服器後由 fetch 讀取 |

兩份都放著，頁面會自己挑：有 `window.__TASKS__` 就用它，沒有才 fetch。
所以 `file://` 雙擊和 S3 部署都能跑。

## 現在就能看

```bash
cd liff && python3 -m http.server 8899
# 手機與電腦同網段時，用手機開 http://<電腦IP>:8899 效果最準
```

或直接雙擊 `index.html`。**所有畫面與互動都是完整的**：接受任務、導航、到站回報、
完成整趟都會動，狀態存在瀏覽器本機。

頁面上**不再顯示「展示模式」黃條**。那是連線狀態，不是資料真偽——
三個頁面顯示的都是實際的 `tasks.json`，沒有捏造的數字，不需要對觀眾聲明。
連線失敗的原因改寫進 console（`LINE 身分驗證失敗`／`LINE SDK 未載入`／`未設定 LIFF ID`），
要除錯打開開發者工具就看得到。

**沒有跟著拿掉的**（這些講的是數字本身，不是環境）：
- `log.html` 的「里程是實算，碳排是估算」與係數假設值說明
- AI 說明下方的來源標示（`Gemini 生成` / `規則模板生成`）——
  模板文字不該被當成模型輸出
- 大螢幕「示範資料（非即時）」橫幅——那個模式底下是捏造的數字，拿掉等於把假數字當真的講

## 上線要改的只有三行

**由後端（Lambda Function URL）供頁時什麼都不用改**——`serveLiffPage` 會在回應時
把 `liffId` 與 `apiBase` 注入這三個頁面。只有**靜態託管**（GitHub Pages、S3）
才需要手動填，而且**三個檔案都要填**：`index.html`、`urgent.html`、`log.html`。

`index.html` 最上方的 `CONFIG`：

```js
const CONFIG = {
  liffId:  '',   // 填入 LIFF ID，例 '2006xxxxxx-AbCdEfGh'
  apiBase: '',   // 填入 API Gateway 端點，例 'https://xxx.execute-api.us-west-2.amazonaws.com/prod'
  truckCapacity: 20,
};
```

- `liffId` 空 → 不呼叫 `liff.init`，用假身分跑（桌面可測）
- `apiBase` 空 → 所有 API 呼叫安靜跳過，操作只存本機（demo 照樣完整）

兩個都填了才會真的打後端。**中途後端掛掉也不會卡住畫面**，`api()` 一律吞掉錯誤。

## 部署（S3 + CloudFront）

```bash
aws s3 sync . s3://<bucket>/liff/ --exclude "README.md"
# CloudFront 綁 HTTPS 後，把該網址填回 LINE Developers → LIFF → Endpoint URL
```

LIFF 的 Endpoint URL 必須是 HTTPS 且不能是 IP。改完**立刻用手機開一次驗證**，不要假設它生效。

## 後端要提供的 5 支 API

全部 `POST`、JSON、需開 CORS（含 `OPTIONS`）。回傳內容前端都不強制要求，失敗就自動降級。

| 路徑 | Body | 用途 |
|---|---|---|
| `/tasks/accept` | `{userId, taskId}` | 調度員接單 |
| `/tasks/decline` | `{userId, taskId}` | 婉拒，調度中心改派 |
| `/tasks/finish` | `{userId, taskId}` | 整趟完成 |
| `/reports` | `{userId, taskId, stationId, stationName, count, condition, note, suggested, action, ts}` | **到站回報，就是模型再訓練的標記資料** |
| `/explain` | `{userId, taskId}` → `{text: "..."}` | Gemini 重新生成路線說明 |

`/explain` 逾時或非 200 時，前端自動顯示 `aiExplainFallback` 模板文字，並標註「已退回規則模板」。

## 已內建的防呆

- **地圖圖磚 3.5 秒沒載到** → 自動換成文字版「路線總覽」橫條，資訊一項不少（現場網路爛也不開天窗）
- **Leaflet 整個沒載到** → 同上
- **localStorage 被封鎖** → 包在 try/catch，改用記憶體
- **LIFF init 失敗** → 顯示原因並降級為展示模式，不是白畫面
- **未登入且不在 LINE 內** → 自動導向 `liff.login()`
- **緊急頁拿不到後端** → 改用連結上的 `waited=`，拿不到就直說「等待時間未知」，
  並在頁尾標明這個數字的來源，不假裝它是即時的
- **緊急頁沒帶 taskId** → 列出目前所有無人接單的工單讓他挑，不是一片空白
- **兩人同時接同一筆** → 後端回 409，慢的那位看到「已被其他調度員接走」並停在原地，
  不會兩台車跑同一條路線

## 在 LINE 內的額外行為

接受 / 婉拒 / 完成時，會用 `liff.sendMessages` 在聊天室留下一行紀錄
（例「✅ 已接受派工 T003｜土城區 4 站，預估 32 分鐘」），
讓調度中心在 OA 對話裡就看得到誰接了什麼。需要 `chat_message.write` scope，
沒有的話會靜默略過，不影響其他功能。

## 資料更新

站況或門檻調整後重跑產生器即可，前端不用動：

```bash
node ../tools/build_tasks.js <appData.js> ../data/tasks.json
cp ../data/tasks.json ../data/tasks.js .
node ../tools/validate_tasks.js ../data/tasks.json
cd ../backend && npm run sync   # 把三個頁面與資料同步進部署目錄
```

上線後改由 AWS 端輸出同樣 schema（見 `../data/SCHEMA.md`），此頁一行都不用改。
